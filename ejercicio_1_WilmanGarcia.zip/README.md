# Calculadora de Sueldo Quincenal

Ejercicio de clase para la materia de Aplicaciones Web. 

Es una aplicación sencilla hecha en un solo archivo PHP (`index.php`) que calcula el sueldo quincenal de un trabajador tomando en cuenta las horas trabajadas en diferentes turnos y aplicando los descuentos de ley (Ahorro Habitacional y Seguro Social) según su escala salarial.

## Archivos
- `index.php`: Contiene tanto el formulario HTML para ingresar los datos, como la lógica en PHP para procesar el cálculo en la misma página usando `isset($_POST['calcular'])`.
- `README.md`: Descripción del ejercicio.


<html>
<head>
    <title>Calculadora de Sueldo</title>
</head>
<body>
    <h2>Cálculo de Sueldo Quincenal</h2>

    <?php
    // Si el botón "calcular" fue presionado, ejecutamos la matemática
    if (isset($_POST['calcular'])) {
        
        $nombre = $_POST['nombre'];
        $cedula = $_POST['cedula'];
        $horas_diurnas = $_POST['diurna'];
        $horas_vespertinas = $_POST['vespertina'];
        $horas_nocturnas = $_POST['nocturna'];

        $pago_diurno = $horas_diurnas * 675;
        $pago_vespertino = $horas_vespertinas * 700;
        $pago_nocturno = $horas_nocturnas * 956.23;

        $sueldo_bruto = $pago_diurno + $pago_vespertino + $pago_nocturno;

        if ($sueldo_bruto < 85000) {
            $porcentaje_ah = 0.001;  // 0.1%
            $porcentaje_ss = 0.0015; // 0.15%
        } elseif ($sueldo_bruto >= 85000 && $sueldo_bruto <= 150000) {
            $porcentaje_ah = 0.0015; // 0.15%
            $porcentaje_ss = 0.002;  // 0.2%
        } else { 
            $porcentaje_ah = 0.003;  // 0.3%
            $porcentaje_ss = 0.0025; // 0.25%
        }

        $descuento_ah = $sueldo_bruto * $porcentaje_ah;
        $descuento_ss = $sueldo_bruto * $porcentaje_ss;

        $sueldo_neto = $sueldo_bruto - $descuento_ah - $descuento_ss;

        echo "<b>Datos del Empleado:</b><br>";
        echo "Nombre: " . $nombre . "<br>";
        echo "Cédula: " . $cedula . "<br><br>";
        
        echo "<b>Desglose del Sueldo:</b><br>";
        echo "Sueldo Bruto: " . $sueldo_bruto . " Bs.<br>";
        echo "Descuento Ahorro Habitacional: " . $descuento_ah . " Bs.<br>";
        echo "Descuento Seguro Social: " . $descuento_ss . " Bs.<br><br>";
        
        echo "<b>Sueldo Quincenal Neto: " . $sueldo_neto . " Bs.</b><br><br>";
        
        // Enlace vacío recarga la página para volver al formulario
        echo '<a href="">Volver a calcular</a>';

    } else {
        // Si no se ha presionado el botón, mostramos el formulario
    ?>

        <!-- El action está vacío para que se envíe a esta misma página -->
        <form action="" method="POST">
            Nombre del Trabajador: <br>
            <input type="text" name="nombre"><br><br>

            Cédula de Identidad: <br>
            <input type="text" name="cedula"><br><br>

            Horas Diurnas: <br>
            <input type="text" name="diurna"><br><br>

            Horas Vespertinas: <br>
            <input type="text" name="vespertina"><br><br>

            Horas Nocturnas: <br>
            <input type="text" name="nocturna"><br><br>

            <!-- Le agregamos el name="calcular" para que el PHP sepa que se envió -->
            <input type="submit" name="calcular" value="Calcular Sueldo">
        </form>

    <?php
    } // Cerramos la condición del formulario
    ?>
</body>
</html>